from tensorflow.keras.models import load_model
from PIL import Image, ImageOps
import numpy as np
import glob
import os

# Load the model
model = load_model('C:\\Users\\dieuw\\Documents\\Fable\\My Fable Projects\\F vs S v2\\keras_model.h5')
 
# Load labels
with open ('C:\\Users\\dieuw\\Documents\\Fable\\My Fable Projects\\F vs S v2\\labels.txt', 'r') as f:
    class_labels = f.read().split('\n') 

print('The model is loaded, press spacebar to run')
      
#main sorting loop
while True:      
    if api.isPressed('spacebar'):
        print('Running....')
        api.setFaceFocus(0, 0, 0, eyeToChange='both')
        api.setPos(-50, 0, 'AMT')
        api.setSpeed(30, 30, 'AMT')
        api.wait(1) 
        #list_of_files = glob.glob('C:\\Users\\dieuw\\Documents\\Fable\\My Fable Pictures\\*') # * means all if need specific format then *.csv
        #latest_file = max(list_of_files, key=os.path.getctime)
        #if checkexists==exists(latest_file):   
        #    os.remove(latest_file)  
 
        # import the picture 
        data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)
        
        api.takePicture(temp=False, ignoreStorageLimit=False)
        print('Took picture')
        api.wait(1)
        list_of_files = glob.glob('C:\\Users\\dieuw\\Documents\\Fable\\My Fable Pictures\\*') # * means all if need specific format then *.csv
        latest_file = max(list_of_files, key=os.path.getctime)
        print(latest_file)
        
        image = Image.open(latest_file)
           
        #resize the image to a 224x224 with the same strategy as in TM2:
        #resizing the image to be at least 224x224 and then cropping from the center
        size = (224, 224)
        image = ImageOps.fit(image, size, Image.ANTIALIAS)
        
        
        image_array = np.asarray(image)
        #Normalize the image
        normalized_image_array = (image_array.astype(np.float32) / 127.0) - 1
        # Load the image into the array
        data[0] = normalized_image_array
        
        #run the inference
        prediction = model.predict(data) 
        index = np.argmax(prediction)
        name  = class_labels[index]  
        
        print(name)
        #print(in dex)
        print(prediction)
        
        # the sorter
        #steps if functional piece is detected
           
        if index == 0: 
            api.playSound("woof.wav", 'PC') 
            api.setFaceFocus(100, -50, 0, eyeToChange='both')
            print('This Lego piece is functional')
            api.setPos(-60, 20, 'AMT')
            api.setSpeed(30, 30, 'AMT')
            print('Sort step 1')
            api.wait(0.1)
            api.setPos(-40, 0, 'AMT')
            api.setSpeed(30, 30, 'AMT')
            print('Sort step 2')
            api.wait(0.1)  
            api.setPos(-50, -70, 'AMT') 
            api.setSpeed(30, 30, 'AMT')  
            print('Sort step 3')
            api.wait(2)
            api.setPos(0, 0, 'AMT')
            api.setSpeed(30, 30, 'AMT')
            api.wait(0.5)
            print('Back to base 1') 
            api.setPos(-48, 0, 'AMT')
            api.setSpeed(30, 30, 'AMT')
            print('Back to base 2')   
            api.wait(0.1)  
               
        #steps if structural piece is detected
          
        if index == 1: 
            api.playSound("escape.wav", 'PC') 
            api.setFaceFocus(-100, -50, 0, eyeToChange='both')
            print('This Lego piece is Structural')
            api.setPos(0, 0, 'AMT')
            api.setSpeed(30, 30, 'AMT')
            print('Sort step 1')
            api.wait(0.5)
            api.setPos(-55, -50, 'AMT')
            api.setSpeed(30, 30, 'AMT') 
            print('Sort step 2')
            api.wait(0.5)
            api.setPos(-55, 50, 'AMT')   
            api.setSpeed(30, 30, 'AMT')  
            print('Sort step 3') 
            api.wait(2)
            api.setPos(-48, 0, 'AMT') 
            api.setSpeed(30, 30, 'AMT')
            print('Back to base') 
               
        #steps if background is detected  
        if index == 2: 
            api.playSound("theEnd.wav",'PC')
            api.setFaceEmotion('Sleep')
            api.setPos(-48, 0, 'AMT')
            api.setSpeed(30, 30, 'AMT')
            print('No Lego piece detected')
        
    #loop breaker
    if api.isPressed('`'):
        print('Program killed')
        break